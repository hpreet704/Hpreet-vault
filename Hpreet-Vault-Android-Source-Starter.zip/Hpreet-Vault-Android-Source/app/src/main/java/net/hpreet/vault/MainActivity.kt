package net.hpreet.vault

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import android.util.Base64

class MainActivity : Activity() {
    private val pickCode = 44
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var unlocked = false
    private val prefs by lazy { getSharedPreferences("vault_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLock() }
    private fun setupRoot() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(24,30,24,24); setBackgroundColor(0xFF101010.toInt()) }
        setContentView(root)
    }
    private fun title(t: String) { root.addView(TextView(this).apply { text=t; textSize=28f; setTextColor(0xFFFFD700.toInt()); gravity=Gravity.CENTER; setPadding(0,8,0,20) }) }
    private fun label(t: String, size: Float=16f): TextView = TextView(this).apply { text=t; textSize=size; setTextColor(0xFFFFFFFF.toInt()); gravity=Gravity.CENTER; setPadding(0,8,0,8) }
    private fun button(t: String, action: () -> Unit) { root.addView(Button(this).apply { text=t; setTextColor(0xFF111111.toInt()); backgroundTintList=android.content.res.ColorStateList.valueOf(0xFFFFD700.toInt()); setOnClickListener { action() } }, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,8,0,8) }) }
    private fun toast(t: String) = Toast.makeText(this,t,Toast.LENGTH_LONG).show()

    private fun showLock() {
        unlocked=false; setupRoot(); title("Hpreet Vault"); root.addView(label("Private files • Local storage"))
        val pass=EditText(this).apply { hint=if(prefs.contains("pass_hash")) "Enter vault password" else "Create password (8+ characters)"; setHintTextColor(0xFFBBBBBB.toInt()); setTextColor(-1); inputType=129 }
        root.addView(pass,LinearLayout.LayoutParams(-1,-2))
        button(if(prefs.contains("pass_hash")) "Unlock Vault" else "Create Password") {
            val p=pass.text.toString()
            if(p.length<8) toast("Use at least 8 characters.")
            else if(!prefs.contains("pass_hash")) { prefs.edit().putString("pass_hash",hash(p)).apply(); ensureKey(); toast("Password created. Unlock using it now."); showLock() }
            else if(hash(p)==prefs.getString("pass_hash","")) { ensureKey(); unlocked=true; showVault() } else toast("Incorrect password.")
        }
        if(prefs.contains("pass_hash")) button("Unlock with fingerprint / biometrics") { biometricUnlock() }
        root.addView(label("Starter prototype — keep original files backed up.",12f))
    }
    private fun biometricUnlock() {
        if(BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)!=BiometricManager.BIOMETRIC_SUCCESS) { toast("Strong biometrics unavailable. Use password."); return }
        val prompt=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){ super.onAuthenticationSucceeded(result); ensureKey(); unlocked=true; showVault() }
            override fun onAuthenticationError(code:Int, message:CharSequence){ super.onAuthenticationError(code,message); toast(message.toString()) }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock Hpreet Vault").setSubtitle("Authenticate to open your vault").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).setNegativeButtonText("Cancel").build())
    }
    private fun showVault() {
        if(!unlocked){showLock();return}; setupRoot(); title("Hpreet Vault"); root.addView(label("Encrypted files are stored inside this app."))
        button("＋ Import and encrypt a file") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="*/*" },pickCode) }
        button("View encrypted files") { listFiles() }; button("Lock Vault") { showLock() }
        status=label(""); root.addView(status); root.addView(label("Do not uninstall or clear app data; the encryption key may be lost.",12f))
    }
    private fun listFiles() {
        val fs=File(filesDir,"vault").listFiles()?.sortedByDescending{it.lastModified()}?: emptyList()
        status.text=if(fs.isEmpty()) "No encrypted files yet." else fs.joinToString("\n"){ "• "+it.name.removeSuffix(".hvault") }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==pickCode && resultCode==RESULT_OK) { val uri=data?.data?:return; try { encryptFile(uri); toast("File encrypted in Hpreet Vault."); listFiles() } catch(e:Exception){toast("Import failed: ${e.message?:"unknown error"}")} }
    }
    private fun encryptFile(uri:Uri) {
        val key=ensureKey(); val input=contentResolver.openInputStream(uri)?:error("Cannot read file")
        var name="file"; contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { if(it.moveToFirst()) name=it.getString(0)?:name }
        name=name.replace(Regex("[^A-Za-z0-9._ -]"),"_").take(100)
        val dir=File(filesDir,"vault"); if(!dir.exists()&&!dir.mkdirs()) error("Cannot create vault")
        val cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,key); val iv=cipher.iv
        val outFile=File(dir,"${System.currentTimeMillis()}_${name}.hvault")
        input.use { src -> FileOutputStream(outFile).use { out -> out.write("HPVAULT1".toByteArray(Charsets.UTF_8)); out.write(iv.size); out.write(iv); out.write(cipher.doFinal(src.readBytes())) } }
    }
    private fun ensureKey():SecretKey {
        val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
        (ks.getKey("hpreet_vault_aes",null) as? SecretKey)?.let{return it}
        val gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder("hpreet_vault_aes",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        return gen.generateKey()
    }
    private fun hash(p:String):String = Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(p.toByteArray(Charsets.UTF_8)),Base64.NO_WRAP)
}
