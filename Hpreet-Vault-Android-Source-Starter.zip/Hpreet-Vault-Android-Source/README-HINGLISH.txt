HPREET VAULT — ANDROID SOURCE STARTER

Yeh source project ZIP hai, APK nahi. Isko Android Gradle build environment mein open karke APK build karna hoga.

Starter mein:
- Password setup / password gate
- Supported phones par strong biometric prompt
- Android file picker se file import
- AES-GCM encryption aur app-private storage
- Encrypted filenames ki list

IMPORTANT LIMITS:
- Yeh security-audited final product nahi, sirf starter prototype hai.
- Abhi decrypt/export, encrypted backup/restore, password recovery aur full file management implement nahi hain.
- Password hashing abhi simple SHA-256 prototype hai; production ke liye salted password KDF, rate limiting aur security review chahiye.
- Biometric screen abhi app-access gate hai; key use ko biometric prompt se cryptographically bind nahi kiya gaya.
- App uninstall / app data clear hone par Android Keystore key lost ho sakti hai. Original files ka backup rakhein.
- Is prototype mein apni important files ki only copy mat rakhein.
- Is environment mein live Android build/test run nahi hua.

Build: project ko Android Gradle compatible IDE/build service mein open karein aur assembleDebug run karein. Output aam taur par app/build/outputs/apk/debug/ mein hota hai.
Package: net.hpreet.vault | Minimum Android API 26
